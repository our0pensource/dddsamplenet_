# CQRS - Event Sourcing variant of DDDSample.NET
{anchor:Aggregates}
## Aggregates

The following image shows that in CQRS - Event Sourcing variant there is only one (compared to there in vanilla version) aggregate present: the Cargo aggregate.
![](CQRS - Event Sourcing_Domain.png)

In addition to standard elements, in Event Sourcing version, **Cargo** aggregate contains a new kind of objects: events representing explicit state transitions of the aggregate. After executing domain logic, the event representing corresponding state change is instantiated and _published_ to both internal event store and external systems. The latter mechanism is used to transport state change notifications to the query side of the system.

There is only one entity present in the system: {{Cargo}}.
{anchor:Reporting}
## Reporting model

Reporting model is almost identical to the [one in CQRS variant](CQRS#Reporting).