# CQRS variant of DDDSample.Net
{anchor:Aggregates}
## Aggregates

The following image shows that in CQRS variant there are only two (co,pared to there in vanilla version) aggregates present: Cargo and Location.

![](CQRS_Domain.png)

**Cargo** contains logic responsible for manipulating Cargo objects from both administrative and customer's point of view. Note that {{Delivery}} object describing current state of cargo delivery was removed from the aggregate. It's is, however, present in the codebase but only as a transient object which is published through [Domain Events](http://www.udidahan.com/2009/06/14/domain-events-salvation) pattern immediately after creation. Handling event entities have been attached to Cargo aggregate and redundant Handling aggregate was removed. It's sole purpose was to allow asynchronous handling event processing. This requirement is fulfilled by CQRS design itself.

**Location** is part of supporting subdomain which models location concepts such as [UN/LOCODE](http://en.wikipedia.org/wiki/UN/LOCODE).
{anchor:Entities}
## Entities

There are only three entities in CQRS variant of DDDSample.Net:

**Cargo** entity is the main one.

**Location** is an entity which represents a place where cargoes being are handled, for example a port. Locations also have strong identity concept--they are identified by established [UN/LOCODE](http://en.wikipedia.org/wiki/UN/LOCODE) standard codes.

**HandlingEvent** represents simple cargo handling activity. It has been moved from it's own Handling aggregate to the Cargo aggregate.
{anchor:ValueObjects}
{anchor:Reporting}
## Reporting model

In addition to domain model, CQRS variant of DDDSample.Net contains also a _reporting model_. This is a view of domain from querying and reporting perspective. It could be described as a [persistent view model](http://www.udidahan.com/2009/12/09/clarified-cqrs/): a data store which can be directly bound to search and details controls of user interface. The following picture shows simplicity of reporting model in DDDSample.Net:
![](CQRS_Reporting.png)
It contains only two objects: {{Cargo}} and {{Delivery}}. The former represents persistent properties of a cargo, such as route specification and itinerary. The latter contains the temporary state calculated after processing every handling event. There is a collection of {{Delivery}}s associated with each {{Cargo}} and each {{Cargo}} instance points to a most recent one as its current state.