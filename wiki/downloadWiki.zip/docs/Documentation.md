# DDDSample.NET documentation

# [Running the demo](Running-the-demo)
# [Versions of DDDSample](Versions-of-DDDSample)
# [Design of Domain Model in DDDSample.Net](Design-of-Domain-Model-in-DDDSample.Net)
## [Alternative: Layered Model](Layered-Model)
## [Alternative: CQRS](CQRS)
## [Alternative: CQRS - Event Sourcing](CQRS---Event-Sourcing)
# [Patterns reference](Patterns-reference)