# Versions and modes of DDDSample.Net

DDDSample.Net currently comes in four different versions. Each versions presents a lightly different application of Domain Driven Design principles and patterns.

## Classic / Vanilla

This is historically the first version. It is a direct port of Java [DDDSample](http://dddsample.sourceforge.net). I tried to keep as close to the original design, as possible. The only differences are described in these two articles: [value objects](http://simon-says-architecture.com/2009/10/10/value-objects), [entities](http://simon-says-architecture.com/2009/10/28/entities).

Classic version comes in two different operation modes: **synchronous** and **asynchronous**. This qualification is based on the way Domain Events are processed. In synchronous (default) mode, when a domain event is published, it is **immediately, synchronously** (on the same thread) processed by a handler. In asynchronous operation mode events are **transformed to messages** and published using [NServiceBus](http://www.nservicebus.com). Messages are then processed by NServiceBus runtime via dedicated message handlers which transform messages back to domain model operations.

## CQRS

This version implements Command and Query Responsibility Segregation principle. CQRS advocates separation (physical, logical or both) of command and query processing facilities. There are some elements of CQRS present in classic DDDSample.NET. For example, there are two distinct aggregates representing cargo from different perspectives: {{Handling}} aggregate is optimized for transaction processing while {{Cargo}} aggregate is optimized for queries. CQRS version, however, makes all these segregation concepts explicit.

There are separate models for domain (commands) and reporting (queries). Both models have their own persistence layers (based on NHibernate). Application layer (which is a facade of the domain) invokes operations on domain objects. Side effects of these operations are published through domain events which are then transformed to NServiceBus messages. These messages are processed by reporting facility and appropriate updates are applied to reporting data structures.

## CQRS - LINQ to SQL

This version is a variant of previous solution in which reporting model and persistence was implemented using LINQ to SQL. The sole purpose of this version is to demonstrate inherent simplicity of reporting model. As said Udi Dahan, CQRS reporting side is so simple, that it is literally a **persistent view model.**

## CQRS - Event Sourcing

This version shows a slightly different approach to CQRS. It follows Greg Young ideas (very well documented by Mark Nijhof) of CQRS combined with Event Sourcing. The command facility uses Event Sourcing-based persistence mechanisms. Domain objects are represented by a series of events which have business meaning (like {{DestinationChangedEvent}}) rather than snapshots of last state.

In addition to these changes, also UI -- domain communication has been changed. It uses commands to represent business operations. For demonstration purposes commands are not directly executed on web tier but are send using NServiceBus and dispatched to appropriate handlers.