## Project Description
A .NET implementation of Domain Driven Design (DDD) sample application based on Eric Evans' examples included in his great book. Project is intended to be used in training, demonstration and experiments. 

To see instructions on how to run the [release:0.9 version](45898) of the application [click here](Running-the-demo).

Documentation subjects include discussion of [DDD building blocks in DDDSample.Net](DDD-building-blocks-in-DDDSample.Net) and description of various [versions and modes of DDDSample](versions-and-modes-of-DDDSample).

Project progress information and design discussions are published regularly on DDDSample's section of [my blog](http://simon-says-architecture.com/tag/dddsample/). Click here ![Feed](Home_http://i3.codeplex.com/Images/v15760/icon_rss.gif|http://feeds.feedburner.com/dddsamplenet) to subscribe to the feed. 

## News

* **May 25**: New version -- [release:release 0.9](45898) contains an update to classic (vanilla) version and a [RavenDB](http://ravendb.net) port of Event Sourcing version
* **May 4**: Redesign -- Vanilla branch is now almost compatible with DDDSample thanks to changes in Handling aggregate
* **Apr 30**: New branch -- AutoPersistence is a branch of vanilla version that uses concept-proof modified FluentNHibernate to infer all the database mappings from the structure of the domain model
* **Apr 18**: Documentation update -- added [Layered Model](Layered-Model) chapter describing upcoming Layerd Model version of DDDSample.Net (currently available only in trunk version)
* **Mar 22**: Documentation update -- added [Patterns reference](Patterns-reference) page describing various design and architectural patterns used in DDDSample.Net
* **Mar 20**: New version -- [release:release 0.8](42247) contains, in addition to classic version, also a CQRS one and an Event Sourcing one.

## Goals 
(inspired by [DDDSample](http://dddsample.sourceforge.net)'s purpose)

* ~~**Done: A how-to example for implementing a typical DDD application.**~~ Our sample is not going to show **the** way to do it, but a decent way. Our initial short-term goal is to keep de design as close to DDDSample as possible to make comarations between technologies more easy.

* ~~**Done: Lab mouse for controlled experiments.**~~ We will focus on different DDD patterns and their impact on shape of the solution. We hope to inspire the community to create forks and branches of the sample using different design approaches like Command Query Separation.

* **Support discussion of implementation practices.** Variations could show trade-offs of alternative approaches, helping the community to clarify and refine best practices for building DDD applications.

## Hot builds, directly from trunk
{rss:url=http://feeds.feedburner.com/DddsampleNetBuilds?format=xml,max=3,titlesOnly=true}